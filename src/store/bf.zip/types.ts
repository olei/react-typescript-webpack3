import keyMirror from 'key-mirror'

export default keyMirror({
  GET_SITE_DATA: null,
  GET_SITE_INFO: null,
  GET_SITE_STATS: null,
  GET_ALL_NODES: null
})
