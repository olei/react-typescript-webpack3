import global from './modules/global/globalReducer'
const rootReducer = {
  /* your reducers */
  global
}
export default rootReducer
