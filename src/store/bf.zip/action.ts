import global from './modules/global/globalAction'
const rootAction = {
  /* your reducers */
  global
}
export default rootAction