/**
 * Created by yongyuehuang on 2017/6/7.
 */
export default (cls: any) => ({
  type: 'GET_SITE_DATA',
  cls
})